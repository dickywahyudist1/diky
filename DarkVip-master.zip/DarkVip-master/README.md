# DarkFB Termux

<ul>
<li><code>pkg install git python2</code></li>
<li><code>pip2 install --upgrade pip</code></li>
<li><code>git clone https://github.com/TheMagizz/DarkVip</code></li>
<li><code>cd DarkVip</code></li>
<li><code>pip2 install -r requirements.txt</code></li>
<li><code>python2 darkvip.py</code></li>
</ul>
<br />
<br />
<img src="https://github.com/TheMagizz/DarkVip/raw/master/Screenshot_2019-07-07-12-50-24-318_com.termux.png" />
