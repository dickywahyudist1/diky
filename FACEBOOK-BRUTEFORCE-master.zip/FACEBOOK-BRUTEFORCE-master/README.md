# FACEBOOK-BRUTEFORCE
GILANG - BRUTEFORCE FACEBOOK WITH WORDLIST 
■■■■■ *TOOLS TUAN B4DUT* ■■■■■
■■■■■■■ *BRUTEFORCE FACEBOOK WITH WORDLIST* ■■■■■■■

```$apt upgrade && apt update```
```$pkg install python2 git nano```
```$pip2 install requests```
```$git clone https://github.com/TUANB4DUT/FACEBOOK-BRUTEFORCE```
```$cd FACEBOOK-BRUTEFORCE```

* HOW'S TO CREATE WORDLIST WITH YOURSELF ?
$nano wordlist.txt
AFTER THAT SAVE WITH = CTRL + C>>CLICK Y AND ENTER*

*NOW YOU CAN LAUNCH THIS TOOLS WITH*

```$python2 bruteforce.py```


■■■■■■ *HAPPY CRACKING WITH BRUTEFORCE* ■■■■■■

contact? tuanb4dut@gmail.com
