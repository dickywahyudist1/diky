# TOOLSINSTALLERv3
300+ TOOLS IN 1
SEMUA TOOLS YANG KALIAN INSTALL ADA DI DIRECTORY TOOLS INI


$apt update && apt upgrade
$pkg install python python2 vim figlet curl
$pkg install php
$pip2 install lolcat
$pkg install git
$git clone https://github.com/TUANB4DUT/TOOLSINSTALLERv3

```MENJALANKANNYA```

$cd TOOLSINSTALLERv3
$chmod +x TUANB4DUT.sh
$sh TUANB4DUT.sh

TUAN B4DUT
INDONESIAN TERMUX ASSOCIATION
