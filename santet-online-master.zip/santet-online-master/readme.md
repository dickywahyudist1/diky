# santet-online
Santet-Online adalah alat rekayasa sosial dengan subfungsi yang berfokus dalam menyerang penyandang kebutuhan sosial seseorang, seperti jasa sosial media dan short message service.  
Serangan yang dilancarkan tersebut selalu terkait aktifitas spamming (pesan yang dikirimkan berulang-ulang), spoofing dan bruteforce engineering, untuk subfungsi dos atau denial of service tidak lain dan tidak bukan, hanya untuk menarik peminat pengguna saja.

Catatan: Santet-Online tidak terkait dengan aktifitas spiritual melainkan dengan computational activity (spam, spoof, bruteforce), jangan menduga yang tidak-tidak hanya karena nama alat ini  
Peringatan: Untuk kerusakan yang ditimbulkan karena penggunaan dari alat ini bukan tanggung jawab author, anda harus bertanggung jawab sendiri untuk kerusakan yang anda timbulkan dari menggunakan alat ini

**Source Code for Santet Online App** is [Here](https://raw.githubusercontent.com/Gameye98/Gameye98.github.io/master/source/Santet.zip)

### Requirements
• Python 3.x

#### Installation and Using santet-online
```bash
git clone https://github.com/Gameye98/santet-online
cd santet-online
python -m pip install -r requirements.txt
python santet.py
```

#### Join US
*.[Facebook](https://mobile.facebook.com/groups/1704985559810669)  
*.[Telegram](https://t.me/BHSec)
*.[Telegram-Channel](https://t.me/bhs3c)
